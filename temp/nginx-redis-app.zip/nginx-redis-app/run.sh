docker run -v ~/projects/exemplos/nginx-redis-app/nginx.conf:/etc/nginx/nginx.conf --name nginx-redis-node -p 80:80 -d nginx

