const {promisify} = require('util')
const redis = require("redis")
const client = redis.createClient({
  host: 'localhost',
  port: 6379
})

client.on('error', err => {
  console.log('Redis Error', err)
})

//salvar string
client.set('nome', 'joão da silva')
client.get('nome', (err, nome) => {
  console.log(nome)
})

//salvar um objeto
client.hmset('produto', {
  nome: 'Coca Cola',
  valor: 801
}, redis.print)//print apresenta o resultado da operação no console


//recuperar um objeto
client.hgetall('produto', (err, produto) => {
  console.log(produto)
})


//usando promessas

const get = promisify(client.get).bind(client)

client.set('outroNome', 'Maria')
get('outroNome').then(nome => console.log(nome))


